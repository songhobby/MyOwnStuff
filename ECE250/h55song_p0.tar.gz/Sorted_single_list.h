/*****************************************
 * Instructions
 *  - Replace 'uwuserid' with your uWaterloo User ID
 *  - Select the current calendar term and enter the year
 *  - List students with whom you had discussions and who helped you
 *
 * uWaterloo User ID:  uwuserid @uwaterloo.ca
 * Submitted for ECE 250
 * Department of Electrical and Computer Engineering
 * University of Waterloo
 * Calender Term of Submission:  (Winter|Spring|Fall) 201N
 *
 * By submitting this file, I affirm that
 * I am the author of all modifications to
 * the provided code.
 *
 * The following is a list of uWaterloo User IDs of those students
 * I had discussions with in preparing this project:
 *    -
 *
 * The following is a list of uWaterloo User IDs of those students
 * who helped me with this project (describe their help; e.g., debugging):
 *    -
 *****************************************/

#ifndef SINGLE_LIST_H
#define SINGLE_LIST_H

#ifndef nullptr
#define nullptr 0
#endif

#include "Exception.h"
#include <iostream>

template <typename Type>
class Single_node {
		public:
			Type       element;
			Single_node *next_node;

			Single_node(Type const &e = Type(), Single_node *n = 0);
			Type retrieve() const;
			Single_node *next() const;
		};

template <typename Type>
class Sorted_single_list {
	public:

		Sorted_single_list();
		~Sorted_single_list();

		// Accessors

		int size() const;
		bool empty() const;

		Type front() const;
		Type back() const;

		Single_node<Type> *head() const;
		Single_node<Type> *tail() const;

		int count( Type const & ) const;

		// Mutators


		void insert( Type const & );

		Type pop_front();

		int erase( Type const & );

private:
	Single_node<Type> *list_head;
	Single_node<Type> *list_tail;
	int list_size;
};

template <typename Type>
Single_node<Type>::Single_node(Type const &e, Single_node<Type> *n) :
	element(e),
	next_node(n) {
	// empty constructor
}

template <typename Type>
Type Single_node<Type>::retrieve() const {
	// enter your implementation here
	return element;
}

template <typename Type>
Single_node<Type>* Single_node<Type>::next() const {
	// enter your implementation here
	return next_node;
}

/////////////////////////////////////////////////////////////////////////
//                      Public member functions                        //
/////////////////////////////////////////////////////////////////////////
template <typename Type>
Sorted_single_list<Type>::Sorted_single_list() :
	list_head(nullptr),
	list_tail(nullptr),
	list_size(0) {
	// empty constructor
}



template <typename Type>
Sorted_single_list<Type>::~Sorted_single_list() {
	Single_node<Type> *pre = nullptr;
	Single_node<Type> *cur = list_head;
	while(cur != nullptr){
		pre = cur;
		cur = cur->next();
		delete(pre);
	}
	list_head=nullptr;
	list_tail=nullptr;
	list_size = 0;
	// enter your implementation here
}

template <typename Type>
int Sorted_single_list<Type>::size() const {
	// enter your implementation here
	return list_size;
}

template <typename Type>
bool Sorted_single_list<Type>::empty() const {
	// enter your implementation here
	return list_size == 0;
}

template <typename Type>
Type Sorted_single_list<Type>::front() const {
	// enter your implementation here
	if(empty()) throw underflow();
	return list_head->retrieve();
}

template <typename Type>
Type Sorted_single_list<Type>::back() const {
	// enter your implementation here
	if(empty()) throw underflow();
	return list_tail->retrieve();
}

template <typename Type>
Single_node<Type> *Sorted_single_list<Type>::head() const {
	// enter your implementation here
	return list_head;
}

template <typename Type>
Single_node<Type> *Sorted_single_list<Type>::tail() const {
	// enter your implementation here
	return list_tail;
}

template <typename Type>
int Sorted_single_list<Type>::count(Type const &obj) const {
	// enter your implementation here
	int count=0;
	Single_node<Type>* cur = head();
	while(cur != nullptr){
		count+=(cur->retrieve() == obj);
		if(cur->retrieve()>obj) break;
		cur = cur->next();
	}
	return count;
}

template <typename Type>
void Sorted_single_list<Type>::insert(Type const &obj) {
	// enter your implementation here
	Single_node<Type>* new_node = new Single_node<Type>(obj,nullptr);
	if(empty()){
		list_head = list_tail = new_node;
	}else{
		Single_node<Type>* pre = nullptr;
		Single_node<Type>* cur = head();
		while(cur != nullptr){
			if(cur->retrieve() >= obj){
				if(pre == nullptr){
					list_head = new_node;
					new_node->next_node = pre;
					return;
				}else{
					pre->next_node = new_node;
					new_node->next_node = cur;
					return;
				}
			}
			pre = cur;
			cur = cur->next();
		}
		list_tail->next_node=new_node;
		list_tail = new_node;
	}
	list_size+=1;
	return;
}

template <typename Type>
Type Sorted_single_list<Type>::pop_front() {
	// enter your implementation here
	if(empty()) throw underflow();
	Single_node<Type>* cur = list_head;
	Type value = cur->retrieve();
	if(size() == 1){
		delete list_head;
		list_head=list_tail=nullptr;
	} else{
		list_head = list_head->next_node;
		delete cur;
	}
	list_size-=1;
	return value;
}

template <typename Type>
int Sorted_single_list<Type>::erase(Type const &obj) {
	// enter your implementation here
	if(empty()) return 0;
	int count = 0;
	Single_node<Type>* pre = nullptr;
	Single_node<Type>* cur = head();
	while(cur != nullptr){
		if(cur->retrieve() == obj){
			count+=1;
			if(pre == nullptr){
				if(cur->next_node == nullptr){
					delete list_head;
					list_head=list_tail=nullptr;
					return count;
				}else{
					list_head=list_head->next_node;
					delete cur;
				}
			}
			pre->next_node=cur->next_node;
			cur=cur->next_node;
		}
	}
	list_size-=count;
	return count;
}


#endif
